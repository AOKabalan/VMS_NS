Choose between different meshes consisting of squares: [16^2](quads_16x16), [32^2](quads_32x32), [64^2](quads_64x64), [128^2](quads_128x128), [256^2](quads_256x256) 
