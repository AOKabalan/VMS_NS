Choose between different meshes consisting of squares: 16^2, 32^2, 64^2, 128^2, 256^2
