All the "Cons2DKH-..." files contain the following columns:
t	tbar	kinetic-energy-u_h	enstrophy-u_h	palinstrophy-u_h	L2-norm-div-u_h	

All the "VortThick-..." files contain the following columns:
tbar	vorticity-thickness-u_h	
	