Here, you find data for the results where different kinds of perturbations are present.
All data here is for Reynolds number 100000.
The name of the folder clearly indicates the particular perturbation.
